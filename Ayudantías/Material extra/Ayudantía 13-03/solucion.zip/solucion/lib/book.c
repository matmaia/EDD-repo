#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "books.h"
#include "herramientas.h"

Book*** crear_librero(int n, int m) {
    Book*** librero = calloc(n, sizeof(Book**)); // Librero con N filas
    for (int i = 0; i < n; i++) {
        librero[i] = calloc(m, sizeof(Book*)); // Cada fila con M libros
    }

    // Inicializar en NULL los punteros a libros
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            librero[i][j] = NULL;
        }
    }

    return librero;
}

Book* book_init(char* titulo, char* autor, float puntuacion) {
    Book* libro = malloc(sizeof(Book));
    libro->titulo = strdup(titulo);
    libro->autor = strdup(autor);
    libro->puntuacion = puntuacion;
    return libro;
}

void free_books(Book*** librero, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (librero[i][j] != NULL) {
                free(librero[i][j]->titulo);
                free(librero[i][j]->autor);
                free(librero[i][j]);
            }
        }
        free(librero[i]);
    }
    free(librero);
}


bool poner_libro(Book* libro, Book*** librero, int n, int m) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      if (librero[i][j] == NULL) { // Asumiendo que un libro vacío tiene titulo NULL
        librero[i][j] = libro; // Colocamos el libro en la posición vacía
        printf("Libro '%s' colocado en la posición [%d][%d]\n", libro->titulo, i, j);
        return true;
      }
    }
  }
  printf("No hay espacio para colocar el libro: %s\n", libro->titulo);
  return false;
}

Book* encontrar_por_autor(Book*** librero, int n, int m, char* autor) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (librero[i][j] != NULL && string_equals(librero[i][j]->autor, autor)) {
                return librero[i][j];
            }
        }
    }
    return NULL; // No se encontró ningún libro del autor  
}

Book* encontrar_mayor_puntuacion(Book*** librero, int n, int m) {
    Book* mejor_libro = NULL;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (librero[i][j] != NULL) {
                if (mejor_libro == NULL || librero[i][j]->puntuacion > mejor_libro->puntuacion) {
                    mejor_libro = librero[i][j];
                }
            }
        }
    }
    return mejor_libro; // Retorna el libro con la mayor puntuación o NULL si no hay libros
}


