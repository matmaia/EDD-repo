// [] [] []
// [] [] []
// [] [] []
// Cada uno con punteros a un libro
// Cada libro con un título, autor y año de publicación
// Vamos a pedir rellenar la biblioteca con 3 libros y luego mostrar la información de cada libro

// La primera línea va a ser la cantidad de libros a cargar en memoria L.
// Le siguen L líneas con la información de cada libro: título, autor y puntuación.


#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "books.h"
#include "herramientas.h"


int main(int argc, char **argv){

    /* Definicion de argumentos */
    check_arguments(argc, argv);
    FILE *input_file = fopen(argv[1], "r");

    int N; // Tamaño del librero (cantidad de filas)
    int M; // Tamaño de cada fila (cantidad de libros por fila)
    int L; // Cantidad de eventos a procesar

    int buffer = fscanf(input_file, "%d", &N);

    if (buffer != 1) {
      printf("Error leyendo N");
      return 1;
    }

    buffer = fscanf(input_file, "%d", &M);

    if (buffer != 1) {
        printf("Error leyendo M");
        return 1;
    }

    buffer = fscanf(input_file, "%d", &L);
    if (buffer != 1) {
        printf("Error leyendo L");
        return 1;
    }

    // Inicializamos el librero con N filas y M libros por fila
    Book*** librero = crear_librero(N, M);

    /* Eventos */
    char command[32];

    for (int i = 0; i < L; i++){
        
        buffer = fscanf(input_file, "%s", command);
        if (buffer != 1) {
            printf("Error reading event");
            return 1;
        }

        // TODO: Procesar eventos
        if (string_equals(command, "PONER_LIBRO")) {
          char titulo[256];
          char autor[256];
          float puntuacion;
          buffer = fscanf(input_file, "%255s %255s %f", autor, titulo, &puntuacion);
          if (buffer != 3) {
              printf("Error reading book information");
              return 1;
          }
          Book* libro = book_init(titulo, autor, puntuacion);
          if (!poner_libro(libro, librero, N, M)) {
            free(libro->titulo);
            free(libro->autor);
            free(libro);
          }
        }

        else if (string_equals(command, "ENCONTRAR_POR_AUTOR")) {
          // Cargar el autor a buscar
          char autor[256];
          buffer = fscanf(input_file, "%255s", autor);

          if (buffer != 1) {
            printf("Error reading author information");
            return 1;
          }

          Book* libro_encontrado = encontrar_por_autor(librero, N, M, autor);
          
          if (libro_encontrado != NULL) {
              printf("Libro encontrado: %s por %s con puntuación %.1f\n", libro_encontrado->titulo, libro_encontrado->autor, libro_encontrado->puntuacion);
          } else {
              printf("No se encontró ningún libro del autor: %s\n", autor);
          }
        }   
        
        else if (string_equals(command, "ENCONTRAR_MAYOR_PUNTUACION")) {
            Book* mejor_libro = encontrar_mayor_puntuacion(librero, N, M);
            if (mejor_libro != NULL) {
                printf("Libro con mayor puntuación: %s por %s con puntuación %.1f\n", mejor_libro->titulo, mejor_libro->autor, mejor_libro->puntuacion);
            } else {
                printf("No hay libros en el librero.\n");
            }
        } 
        
        else {
            printf("Comando desconocido: %s\n", command);
        }

    }

    
    free_books(librero, N, M);
    fclose(input_file);

    return 0;
}
