# Compilar
gcc -Wall -Wextra -g -I lib -c main.c -o obj/main.o
gcc -Wall -Wextra -g -c lib/book.c -o obj/book.o
gcc -Wall -Wextra -g -c lib/herramientas.c -o obj/herramientas.o

# Linkear
gcc -o out obj/main.o obj/book.o obj/herramientas.o