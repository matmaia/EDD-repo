#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "herramientas.h"

bool string_equals(char *string1, char *string2) {
    return !strcmp(string1, string2);
}

void check_arguments(int argc, char **argv) {
    if (argc != 2) {
        printf("Modo de uso: %s INPUT\n", argv[0]);
        printf("Donde:\n");
        printf("\tINPUT es la ruta del archivo de input\n");
        exit(1);
    }
}