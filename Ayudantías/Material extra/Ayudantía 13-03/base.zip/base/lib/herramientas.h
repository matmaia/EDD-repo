#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

bool string_equals(char *string1, char *string2);
void check_arguments(int argc, char **argv);

