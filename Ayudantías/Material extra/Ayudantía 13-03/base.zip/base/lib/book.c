#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "books.h"
#include "herramientas.h"

/*
Función que recibe las dimensiones de un tablero y pide la memoria necesaria para crear un tablero de esas dimensiones. 
Retorna un puntero al tablero creado, donde todos los punteros iniciales son NULL.
*/
Book*** crear_librero(int n, int m) {
    Book*** librero = calloc(n, sizeof(Book**)); // Librero con N filas
    for (int i = 0; i < n; i++) {
        librero[i] = calloc(m, sizeof(Book*)); // Cada fila con M libros
    }

    // Inicializar en NULL los punteros a libros
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            librero[i][j] = NULL;
        }
    }

    return librero;
}

/*
Función que recibe los datos necesarios para crear un libro, pide la memoria necesaria para crear el libro y retorna un puntero al libro creado.
Ojo con cómo se están guardando los strings título y autor 0.0
*/
Book* book_init(char* titulo, char* autor, float puntuacion) {
    Book* libro = malloc(sizeof(Book));
    libro->titulo = strdup(titulo);
    libro->autor = strdup(autor);
    libro->puntuacion = puntuacion;
    return libro;
}

/*
Función que recibe un librero y sus dimensiones, y libera toda la memoria asociada a los libros y al librero.
*/
void free_books(Book*** librero, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (librero[i][j] != NULL) {
                free(librero[i][j]->titulo);
                free(librero[i][j]->autor);
                free(librero[i][j]);
            }
        }
        free(librero[i]);
    }
    free(librero);
}

// TODO: FUNCIONES A COMPLETAR
bool poner_libro(Book* libro, Book*** librero, int n, int m) {
  /* 
  El objetivo de la función es recorrer el librero (primero por las filas, y después por las columnas) y colocar el libro en el librero.
  De ser exitosa la operación se printea "Libro 'titulo' colocado en la posición [i][j]" y se retorna true. 
  En caso de no haber espacio para colocar el libro, se printea "No hay espacio para colocar el libro: titulo" y se retorna false.
  */
}

Book* encontrar_por_autor(Book*** librero, int n, int m, char* autor) {
  /*
  El objetivo de la función es recorrer el librero (primero por las filas, y después por las columnas) y encontrar el primer libro del autor que se busca.
  De ser exitosa la operación se retorna un puntero al libro encontrado. 
  En caso de no encontrar ningún libro del autor, se retorna NULL.
  */
}

Book* encontrar_mayor_puntuacion(Book*** librero, int n, int m) {
  /*
  El objetivo de la función es recorrer el librero (primero por las filas, y después por las columnas) y encontrar el libro con la mayor puntuación.
  De ser exitosa la operación se retorna un puntero al libro encontrado. 
  En caso de no haber ningún libro en el librero, se retorna NULL.
  */
}


