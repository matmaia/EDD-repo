#include <stdbool.h>

typedef struct book {
  char* titulo;
  char* autor;
  float puntuacion;
} Book;

// Lista
Book*** crear_librero(int n, int m);
Book* book_init(char* titulo, char* autor, float puntuacion);
void free_books(Book*** librero, int n, int m);

// TODO

bool poner_libro(Book* libro, Book*** librero, int n, int m);
Book* encontrar_por_autor(Book*** librero, int n, int m, char* autor);
Book* encontrar_mayor_puntuacion(Book*** librero, int n, int m);


