#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "books.h"
#include "herramientas.h"


int main(int argc, char **argv){

    /* Definicion de argumentos */
    check_arguments(argc, argv);
    FILE *input_file = fopen(argv[1], "r");

    int N; // Tamaño del librero (cantidad de filas)
    int M; // Tamaño de cada fila (cantidad de libros por fila)
    int L; // Cantidad de eventos a procesar

    int buffer = fscanf(input_file, "%d", &N);

    if (buffer != 1) {
      printf("Error leyendo N");
      return 1;
    }

    buffer = fscanf(input_file, "%d", &M);

    if (buffer != 1) {
        printf("Error leyendo M");
        return 1;
    }

    buffer = fscanf(input_file, "%d", &L);
    if (buffer != 1) {
        printf("Error leyendo L");
        return 1;
    }

    // Inicializamos el librero con N filas y M libros por fila
    Book*** librero = crear_librero(N, M);

    /* Eventos */
    char command[32];

    for (int i = 0; i < L; i++){
        
        buffer = fscanf(input_file, "%s", command);
        if (buffer != 1) {
            printf("Error reading event");
            return 1;
        }

        // TODO: Procesar eventos
        if (string_equals(command, "PONER_LIBRO")) {
          // TODO: Poner el libro en el librero en el primer espacio libre. (Ver función poner_libro)
        }

        else if (string_equals(command, "ENCONTRAR_POR_AUTOR")) {
          /*
          TODO: Encontrar el primer libro del autor que se busca y mostrar su información. (Ver función encontrar_por_autor)
          Si se encuentra un libro del autor, se debe mostrar su información en el siguiente formato: 
            "Libro encontrado: 'titulo' por 'autor' con puntuación 'puntuacion'".
          En caso de no encontrar ningún libro del autor, se debe mostrar el mensaje: 
            "No se encontró ningún libro del autor: 'autor'".
          */
        }   
        
        else if (string_equals(command, "ENCONTRAR_MAYOR_PUNTUACION")) {
            /*
            TODO: Encontrar el libro con la mayor puntuación y mostrar su información. (Ver función encontrar_mayor_puntuacion)
            Si se encuentra un libro con la mayor puntuación, se debe mostrar su información en el siguiente formato: 
              "Libro con mayor puntuación: 'titulo' por 'autor' con puntuación 'puntuacion'".
            En caso de no haber ningún libro en el librero, se debe mostrar el mensaje:
              "No hay ningún libro en el librero".
            */
        } 
        
        else {
            printf("Comando desconocido: %s\n", command);
        }

    }


    // Liberamos la memoria del librero y del archivo de entrada (recordar open close de python)
    free_books(librero, N, M);
    fclose(input_file);

    return 0;
}