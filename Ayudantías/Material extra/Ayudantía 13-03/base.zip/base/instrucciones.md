# Ayudantía 13 de marzo

## Objetivo
Hay varios TODO dentro del código que hay que rellenar.

El objetivo general es completas las operaciones necesarias para poder:

1. Poner un libro dentro de un librero de tamaño definido.

2. Encontrar el primer libro guardado de un autor en específico.

3. Encontrar el libro mejor puntuado.

## Ejecución
Para este ejercicio vamos a compilar el código con gcc de forma indirecta mediante `./run.sh`, código de shell que compila los archivos `main.c`, `book.c` y `herramientas.c` y los _linkea_ tal que se puedan ocupar.

Ya compilado el código vamos a querer usar el ejecutable de la siguiente manera:

`./out <INPUT_FILE>`

Para facilitar el testeo del código les dejé una carpeta `/test`, la cual trae 3 tests con sus respectivos input y output.

Un ejemplo de flujo completo sería:

```
> // ...Termino de completar los TODO.
> ./run.sh // Lo que genera un archivo de salida 'out'
> ./out test/test_1/INPUT.txt
Libro 'Dune' colocado en la posición [0][0]
Libro 'DonQuijoteDeLaMancha' colocado en la posición [0][1]
Libro 'CienAñosDeSoledad' colocado en la posición [1][0]
Libro 'FranzKafka' colocado en la posición [1][1]
No hay espacio para colocar el libro: FScottFitzgerald
Libro encontrado: Dune por FrankHerber con puntuación 8.6
Libro con mayor puntuación: DonQuijoteDeLaMancha por MiguelDCervantes con puntuación 9.9
```



